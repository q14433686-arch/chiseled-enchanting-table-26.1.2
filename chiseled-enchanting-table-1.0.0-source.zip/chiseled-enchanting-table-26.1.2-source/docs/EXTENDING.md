# Extending the Chiseled Enchanting Table (data-driven)

This mod follows a strict split: **Java = mechanism/loading/registration/sync/UI/validation**,
**JSON = content/values/rule tables**. Almost everything a content creator wants to change is JSON
and works from a datapack — no Java edits or recompilation.

## Data-pack layout (MC 26.1.2 — singular dirs!)

```
data/<namespace>/
  loot_table/blocks/<block>.json      # NOTE: singular "loot_table", not "loot_tables"
  recipe/<recipe>.json                # singular "recipe"
  advancement/<adv>.json              # singular "advancement"
  tags/block/...                      # singular "block"
  chiseled_enchanting_table/
    default_enchantments.json
    enchantment_costs.json
    item_transformations.json
```

> The singular `loot_table` / `recipe` / `advancement` naming is the #1 silent-failure trap in
> 26.x: a file under the old plural path loads as if it did not exist. `scripts/compat_check.py`
> fails the build if a legacy plural directory appears.

## Extension points

### 1. Default unlocked enchantments — `default_enchantments.json`
```json
{
  "values": [ { "enchantment": "minecraft:sharpness", "level": 1 } ],
  "tags": [ { "tag": "#minecraft:non_treasure", "level": 1 } ]
}
```
`values` lists explicit `{enchantment, level}` entries. `tags` (optional) expands to *every*
enchantment present in a vanilla or modded enchantment tag, resolved against the live registry
each time the table is opened — this is the cross-mod compatibility hook: any enchantment mod
(vanilla or third-party) that tags its enchantments with one of these tags is automatically
included, with nothing to hand-maintain. The default `tags` rule reuses vanilla's own
`#minecraft:non_treasure` tag (the same tag the vanilla enchanting table itself uses to decide
"normal" enchantments), so a well-behaved enchantment-adding mod needs zero configuration here. See
`docs/COMPATIBILITY.md` for the full cross-mod investigation (Ore Enchants-style new-enchantment
mods, Universal Enchants-style item/exclusivity rewrites, Merge Enchantments-style anvil mods).

### 2. Enchantment costs — `enchantment_costs.json`
Supports `options`, `min_count`/`max_count`, `count_per_level`, `level_overrides`, `max_level`,
and per-option `extra`/`extras` (recursive). Top-level `xp` rule with `level_one_cost`,
`common_max_cost`, `rare_single_level_cost`, and per-enchantment `overrides`.

### 3. Item transformations — `item_transformations.json`
```json
{
  "values": [
    {
      "id": "<namespace>:enchanted_golden_apple",
      "input": "minecraft:golden_apple",
      "output": "minecraft:enchanted_golden_apple",
      "level": 1,
      "xp_cost": 3,
      "primary_cost": { "item": "minecraft:gold_block", "count": 8 },
      "additional_costs": [ { "item": "minecraft:emerald", "min_count": 2, "max_count": 5 } ]
    }
  ]
}
```
`primary_cost` is consumed from the cost slot; `additional_costs` are consumed from the player
inventory. Transformation display info (input/output/level) is synced to the client when the menu
opens, so datapack-defined transformations render correctly even on dedicated servers.

## Keeping the built-in fallback in sync

`item_transformations.json` is mirrored by a built-in fallback literal in
`ChiseledEnchantingTableData` so a missing datapack file behaves identically to the bundled file.
If you edit one you must edit the other — `scripts/compat_check.py` fails the build if they drift.

## Run the checks

```bash
python3 scripts/compat_check.py            # offline structural + drift checks (Tier 1)
python3 scripts/compat_check.py --mc-jar <path>   # also cross-check ids vs the MC data jar (Tier 2)
```

Tier 1 failures block the build; Tier 2 emits warnings for ids not seen in the vanilla data jar
(e.g. the `minecraft:scute` -> `minecraft:turtle_scute` rename caught in P16).
