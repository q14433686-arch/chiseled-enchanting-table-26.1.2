# Documentation Index

> **Unofficial community port.** All documents indexed below describe the unofficial 26.1.2 port
> in this repository. It is not affiliated with or endorsed by the original author of
> [`chiseled-enchanting-table`](https://github.com/Sacramentix/chiseled-enchanting-table).
> Current version: **`1.0.0`**.

## Core Setup
- [CURRENT_BASELINE.md](../CURRENT_BASELINE.md): Current architecture capabilities and disabled systems.
- [NEXT_TASK.md](../NEXT_TASK.md): Recommended next steps (1.0.0 live verification + cost-panel decision).
- [EXTENDING.md](EXTENDING.md): Data-driven extension points and the singular-dir data-pack trap (added P16).
- [COMPATIBILITY.md](COMPATIBILITY.md): Cross-mod compatibility investigation for third-party enchantment/anvil mods (added P19).

## Porting Reports (historical pre-1.0.0 internal rounds)

These rounds (P1-P19) document how the unofficial 26.1.2 port was built up before being released
as `1.0.0`. They previously corresponded to `0.2.3+26.1.2-pNN` `mod_version` values; those labels
are kept inside the report bodies as a historical record only, not as live version numbers.

- [P1 Build-system migration](reports/PORTING_26_1_2_P1_REPORT.md)
- [P2 Core server compile slice](reports/PORTING_26_1_2_P2_REPORT.md)
- [P3 Client compile slice and test jar](reports/PORTING_26_1_2_P3_REPORT.md)
- [P5/P6 Runtime smoke boundary and data-driven mechanics](reports/PORTING_26_1_2_P5_P6_REPORT.md)
- [P7 User feedback fixes](reports/PORTING_26_1_2_P7_FIX_REPORT.md)
- [P8 Scroll and chiseled bookshelf level fixes](reports/PORTING_26_1_2_P8_FIX_REPORT.md)
- [P9 Data-driven balance pass](reports/PORTING_26_1_2_P9_DATA_DRIVEN_BALANCE_REPORT.md)
- [P10 balance rework](reports/PORTING_26_1_2_P10_BALANCE_REWORK_REPORT.md)
- [P11 enchantment coverage and recipe balance](reports/PORTING_26_1_2_P11_ENCHANTMENT_TABLE_COVERAGE_REPORT.md)
- [P12 multi-item costs](reports/PORTING_26_1_2_P12_MULTI_ITEM_COST_REPORT.md)
- [P13 item transformations and extensibility review](reports/PORTING_26_1_2_P13_ITEM_TRANSFORMATION_REPORT.md)
- [P14 transformation fix and payload decoupling](reports/PORTING_26_1_2_P14_TRANSFORMATION_FIX_AND_PAYLOAD_REPORT.md)
- [P15 package/UI decoupling](reports/PORTING_26_1_2_P15_DECOUPLING_REPORT.md)
- [P16 loot fix and compat tooling](reports/PORTING_26_1_2_P16_LOOT_FIX_AND_COMPAT_TOOLING_REPORT.md)
- [P17 retire legacy block package](reports/PORTING_26_1_2_P17_BLOCK_PACKAGE_REPORT.md)
- [P18 typed available-option model](reports/PORTING_26_1_2_P18_AVAILABLE_OPTION_MODEL_REPORT.md)
- [P19 cross-mod enchantment compatibility](reports/PORTING_26_1_2_P19_CROSS_MOD_COMPATIBILITY_REPORT.md)
- [Agent Execution Brief](reports/CURRENT_AGENT_BRIEF.md)

*(Note: `JSON_EXTENSION_SPEC_1_1_3.md` and `EXTENDING_HERBCRAFT.md` are not natively part of this specific mod's repository and have been omitted; `EXTENDING.md`/`COMPATIBILITY.md` above are this mod's equivalents.)*
