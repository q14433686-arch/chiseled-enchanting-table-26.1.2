# Next Task: 1.0.0 live verification + multi-slot cost panel decision

> **Unofficial community port.** All instructions below apply to the unofficial 26.1.2 port
> (this repository). The upstream `Sacramentix/chiseled-enchanting-table` project is not affected
> by this version line.

**Current mod version:** `1.0.0` (first stable build of the unofficial 26.1.2 port; see
`CURRENT_BASELINE.md` -> "Versioning" for the rationale for moving off the old
`0.2.3+26.1.2-pNN` scheme).

## Status carried over from the previous round

- The earlier "P19 Live Verification (P17/P18)" checks (enchantment vs. transformation rows, apply
  paths, mining drop, floating book / scroll) were run live by the user and **confirmed passing**.
  No regressions from P17/P18.
- The P19 cross-mod default-unlock change is in the codebase but its *cross-mod half* has only
  been tested in vanilla-only mode so far; the third-party-mod combinations below still need a
  live run before we can call them done.

## 1.0.0 environment is reproducible

A fresh-clone build was re-verified on a sandbox where only JDK 11 ships by default:

```bash
sudo apt-get install -y openjdk-25-jdk-headless     # if Java 25 isn't already on PATH
chmod +x ./gradlew
python3 scripts/compat_check.py                     # offline data-pack sanity (Tier 1 only here)
JAVA_HOME=/usr/lib/jvm/java-25-openjdk-amd64 ./gradlew --no-daemon --max-workers=1 \
    dependencies --configuration compileClasspath
JAVA_HOME=/usr/lib/jvm/java-25-openjdk-amd64 ./gradlew --no-daemon --max-workers=1 \
    processResources --stacktrace
JAVA_HOME=/usr/lib/jvm/java-25-openjdk-amd64 ./gradlew --no-daemon --max-workers=1 \
    -Dorg.gradle.jvmargs='-Xmx1024m -Dfile.encoding=UTF-8' compileJava compileClientJava --stacktrace
JAVA_HOME=/usr/lib/jvm/java-25-openjdk-amd64 ./gradlew --no-daemon --max-workers=1 \
    -Dorg.gradle.jvmargs='-Xmx1024m -Dfile.encoding=UTF-8' build --rerun-tasks --stacktrace
```

All commands above are confirmed BUILD SUCCESSFUL against the current `1.0.0` source tree.
Built artefacts and a working-tree source zip are staged under
`release_output/chiseled_enchanting_table_1_0_0/`.

**Caveat on the original startup sequence:** the standing operating brief calls for running
`python3 scripts/generate_agent_brief.py --write`, but that script does not exist in this repo
(only `scripts/compat_check.py` is present). Treat that step as a no-op for this repository
until/unless the script is added.

## Required live checks for the 1.0.0 release (cross-mod compatibility)

The 1.0.0 build still contains the JSON-only `tags` extension to `default_enchantments.json`
(default: `#minecraft:non_treasure`). Confirm both halves:

1. **No regression (vanilla-only):** with no other mods installed, the chiseled enchanting table's
   default option list should look the same as in the previous `p18` artefact (same vanilla
   enchantments offered by default; the `tags` rule reproduces the previously hand-maintained
   `values` list via `#minecraft:non_treasure` plus the few treasure-only entries kept in
   `values`).
2. **Cross-mod (needs a third-party enchantment mod installed):**
   - Install a mod that registers a new enchantment tagged into `#minecraft:non_treasure` (most
     "add an enchantment" mods do this by default — check the mod's own enchantment JSON or its
     `#minecraft:non_treasure` / `#minecraft:in_enchanting_table` tag additions).
   - Open the chiseled enchanting table **without** placing any book and confirm the new
     enchantment appears in the default option list.
   - Install [Universal Enchants](https://modrinth.com/mod/universal-enchants) and confirm e.g. an
     axe now offers Sharpness as an option (should already work with zero port-specific code, per
     `docs/COMPATIBILITY.md` — confirming live closes that investigation).
   - Install [Merge Enchantments](https://modrinth.com/mod/merge-enchantments) alongside this
     port and confirm neither mod's menu/anvil interaction regresses (separate interaction paths;
     expected to coexist — see `docs/COMPATIBILITY.md`).

## Decoupling backlog status

- [x] Split packages: `data/`, `mechanics/enchanting/`, `mechanics/transformation/`, `menu/`,
  `client/gui/row/`.
- [x] Separate `TransformationRowRenderer` from the enchantment row renderer.
- [x] Move `Block` / `BlockEntity` / `FloatingBook` / `ChiseledBookshelfTick` into a `block`
  package and retire the legacy `chiseledEnchantingTable` package.
- [x] Typed available-option model (`menu.AvailableOption`); stop overloading
  `EnchantmentWithLevel`.
- [ ] **Dedicated multi-slot cost panel** instead of pulling extra materials from the player
  inventory. This is the last item and the largest one — it changes the menu's slot layout and
  client interaction, so it needs explicit design + live client testing before/while building.
  Defer until after the 1.0.0 live verification above is closed.

## Validation required after any change

- `python3 scripts/compat_check.py` (Tier 1 must pass; pass `--extra-jar <path>` when testing
  alongside a specific third-party mod to also get Tier 2 id-existence coverage for its ids).
- JSON syntax validation for changed JSON files.
- `compileJava compileClientJava`.
- `build --rerun-tasks`.
- Jar metadata/resource spot check (`version`, name still marked Unofficial, `mixins=[]`).
- Refresh `release_output/chiseled_enchanting_table_<version>/` if source/resources/jar bytes
  change. The directory name follows `chiseled_enchanting_table_<version with _ for .>`, e.g.
  `chiseled_enchanting_table_1_0_0` for `1.0.0`, `chiseled_enchanting_table_1_0_1` for `1.0.1`.
- Mark validation executed and client-only validation pending.
