# Current Baseline

> **Unofficial community port.** This repository is an unofficial community port of
> [Sacramentix/chiseled-enchanting-table](https://github.com/Sacramentix/chiseled-enchanting-table)
> to Minecraft **26.1.2** on Fabric. It is **not affiliated with, endorsed by, or maintained by
> the original author**. All credit for the original mod design and assets belongs to Sacramentix
> (MIT licensed); this port only updates the code/data to the 26.1.2 toolchain.

**Date:** 2026-07-01
**Minecraft Version:** 26.1.2
**Fabric Loader:** 0.19.3
**Fabric API:** 0.151.0+26.1.2
**Gradle:** 9.4.1
**Loom:** 1.16.3
**Java:** 25.0.3 (system-wide `/usr/lib/jvm/java-25-openjdk-amd64`; on a fresh sandbox install via
`apt-get install -y openjdk-25-jdk-headless`)
**Mod Version:** `1.0.0`  *(unofficial-port versioning, see "Versioning" below)*

## Versioning

Starting with this release, the unofficial port uses a clean SemVer `MAJOR.MINOR.PATCH` line
beginning at **`1.0.0`** instead of the previous `0.2.3+26.1.2-pNN` upstream-derived scheme.

- `1.0.0` is the first stable, publishable build of the unofficial 26.1.2 port.
- The Minecraft target version (`26.1.2`) is no longer baked into `mod_version`; it is declared
  via `depends.minecraft` in `fabric.mod.json` and via the publish workflow's `MINECRAFT_VERSION`.
- The old internal `pNN` round labels (P1-P19) are kept as **historical entries inside
  `CHANGELOG.md` and `docs/reports/PORTING_26_1_2_PNN_*.md`** because they are an accurate record
  of how the port was built up. They no longer correspond to a `mod_version` value.
- Future iterations on top of `1.0.0` should bump SemVer normally (e.g. `1.0.1` for a fix,
  `1.1.0` for a backwards-compatible feature).

## Current Source-Truth Snapshot (what the code/data actually contains today)

### Build / packaging
- `gradle.properties`: `mod_version=1.0.0`, `minecraft_version=26.1.2`,
  `loader_version=0.19.3`, `fabric_version=0.151.0+26.1.2`.
- `src/main/resources/fabric.mod.json`:
  - `version: "${version}"` (substituted by Loom to `1.0.0`).
  - `name`: `Chiseled Enchanting Table (Unofficial 26.1.2 Port)`.
  - `description`: explicitly states this is an unofficial port and not affiliated with the
    original author.
  - `authors`: original `Sacramentix` plus the unofficial-port maintainer `q14433686-arch`.
  - `contact.sources`: this port's GitHub; `contact.homepage`: original upstream.
  - `depends`: `fabricloader >=0.19.3`, `minecraft 26.1.2`, `java >=25`, `fabric-api *`.
  - `mixins: []` (still intentionally empty; see "Active Temporary Boundaries").
  - `custom.chiseled_enchanting_table:port_notes`: documents the unofficial-port status and the
    current mixin/loot/structure boundary.
- `.github/workflows/publish.yml`: `MINECRAFT_VERSION: 26.1.2`, `JAVA_VERSION: 25`,
  `VERSION: 1.0.0`, `RELEASE_NAME: Chiseled Enchanting Table 1.0.0 (Unofficial 26.1.2 Port)`.

### Source layout (post-P17 package split, unchanged this round)
- `chiseled_enchanting_table.block.*` — `ChiseledEnchantingTableBlock`,
  `ChiseledEnchantingTableBlockEntity`, `FloatingBook`, `ChiseledBookshelfTick`
  (the legacy mixed `chiseledEnchantingTable` package has been retired).
- `chiseled_enchanting_table.data.ChiseledEnchantingTableData` — server-data reload listener that
  loads JSON-driven default unlocks, costs, transformations.
- `chiseled_enchanting_table.mechanics.enchanting.EnchantmentApplication` and
  `chiseled_enchanting_table.mechanics.transformation.ItemTransformationApplication`.
- `chiseled_enchanting_table.menu.*` — `ChiseledEnchantingTableScreenHandler`,
  `ChiseledEnchantingMenuPayloads` (`OptionType`, `TransformationDisplay`,
  `AvailableEnchantmentPayload`, `ApplyEnchantmentPayload`), `AvailableOption`
  (typed enchantment vs. transformation).
- `chiseled_enchanting_table.registry.*` — `BlockRegistry`, `EntityRegistry`,
  `ScreenHandlerRegistry`, `StructureProcessorRegistry`.
- `chiseled_enchanting_table.utils.*` — `Advancement`, `BlockPosStream`, `EnchantmentFinder`,
  `EnchantmentWithLevel`, `InventoryUtils`.
- Client (`src/client/java`): `ChiseledEnchantingTableClient`, `ChiseledEnchantingTableScreen`,
  `EnchantementListWidget`, `gui.row.*` (`RowRenderSupport`, `EnchantmentRowRenderer`,
  `TransformationRowRenderer`).

### Data / JSON
- `data/chiseled_enchanting_table/chiseled_enchanting_table/default_enchantments.json` —
  `values` (small list of explicitly-unlocked vanilla treasure enchantments) + `tags`
  (default `#minecraft:non_treasure`, level 1) for cross-mod tag-driven unlocks.
- `data/chiseled_enchanting_table/chiseled_enchanting_table/enchantment_costs.json` — per-level
  item + XP costs, with the `scute` -> `turtle_scute` fix.
- `data/chiseled_enchanting_table/chiseled_enchanting_table/item_transformations.json` — JSON
  source of truth for item transformations; the compat check enforces no drift with the Java
  fallback table.
- Block loot table at the modern singular path
  `data/chiseled_enchanting_table/loot_table/blocks/chiseled_enchanting_table.json` (drops-self,
  with `CopyName` from the block entity). The legacy plural `loot_tables/blocks/` path is gone.

### Tooling
- `scripts/compat_check.py` — Tier 1 (offline, fails the build) covers singular-dir convention,
  no stale plural dirs, non-empty block-loot pools, all-JSON parses, JSON/Java transformation
  drift, and `default_enchantments.json` `tags` schema. Tier 2 (best-effort, warn-only) checks
  id existence against `--mc-jar` and/or `--extra-jar` paths.

### Active Temporary Boundaries (carried over, unchanged)
- Main-source exclusions (still excluded from the compile slice via `build.gradle`): legacy/fragile
  mixins, loot-table modification hooks, structure-processor implementation, integration package,
  `ChiseledBookshelfTick`, and `ChiseledBookshelfLootTable`.
- Runtime feature gaps: mixins (empty list at runtime), loot hooks, structure bookshelf
  replacement, final balancing of shelf-power rules, full live-client gameplay validation.

### Release artifacts (this round)
Staged under `release_output/chiseled_enchanting_table_1_0_0/`:
- `chiseled-enchanting-table-1.0.0.jar`
- `chiseled-enchanting-table-1.0.0-sources.jar`
- `chiseled-enchanting-table-1.0.0-source.zip` (working-tree zip; excludes
  `.git/`, `.gradle/`, `build/`, `release_output/`).

The previous `release_output/chiseled_enchanting_table_26_1_2_p18/` directory has been removed —
the `p18` artifact line was superseded by `1.0.0` at the same source revision.

## Verified This Session (2026-07-01)

- Re-installed `openjdk-25-jdk-headless` on the sandbox (default image only ships JDK 11).
- `chmod +x ./gradlew`.
- `python3 scripts/compat_check.py` -> **`PASS (0 warning(s))`** (Tier 2 not exercised — no
  `--mc-jar` / `--extra-jar` provided).
- `./gradlew dependencies --configuration compileClasspath` -> BUILD SUCCESSFUL.
- `./gradlew processResources --stacktrace` -> BUILD SUCCESSFUL.
- `./gradlew compileJava compileClientJava --stacktrace` -> BUILD SUCCESSFUL.
- `./gradlew build --rerun-tasks --stacktrace` -> BUILD SUCCESSFUL.
- Built jar `fabric.mod.json` spot check: `version=1.0.0`, name marked as Unofficial 26.1.2 Port,
  authors include both original and port maintainer, `depends.minecraft=26.1.2`, `mixins=[]`.

## Client-Only / Live-Game Validation Still Pending

Same as the prior baseline — these require a real MC 26.1.2 + Fabric runtime and were not run in
this headless sandbox: mod-metadata load, block placement, custom menu open, slot/scroll/floating
book renderer, enchanting + transformation application, chiseled-bookshelf scanning, P19 tag-based
cross-mod default unlocks, multiplayer sync beyond payload registration, and mining drop in a
live world. The full list is kept in `docs/reports/CURRENT_AGENT_BRIEF.md`.
