#!/usr/bin/env python3
"""
Automated compatibility / sanity checker for the Chiseled Enchanting Table mod.

Why this exists
---------------
P15 shipped a bug where the block dropped nothing when mined, because the block loot
table lived at the *old plural* path ``data/<ns>/loot_tables/blocks/...`` and had empty
pools. Minecraft 26.1.2 expects the *singular* path ``data/<ns>/loot_table/blocks/...``
(same singularisation as ``recipe`` and ``advancement``), so the file was silently never
loaded. This script encodes that whole class of "silently wrong data-pack layout / empty
content" mistakes so it can be caught in CI instead of in a live client.

Two tiers of checks
-------------------
Tier 1 (offline, deterministic, FAILS the build):
  * Data-pack directory naming uses the modern singular convention.
  * No stale plural directories (loot_tables / recipes / advancements / tags/*s).
  * Block loot tables have non-empty pools and drop something.
  * All ``*.json`` under src parse.
  * The JSON item_transformations table matches the Java built-in fallback (no drift
    between the two sources of truth).
  * ``default_enchantments.json``'s ``tags`` entries (if present) are well-formed: each
    has a syntactically valid ``tag`` resource location (optionally ``#``-prefixed) and a
    positive integer ``level``. This is the cross-mod compatibility extension point (see
    ``docs/COMPATIBILITY.md``): any third-party enchantment mod that tags its enchantments
    with one of these tags (e.g. the vanilla ``#minecraft:non_treasure`` default) is picked
    up automatically, so this check only has to guard against typos in the tag id itself.

Tier 2 (best-effort, needs the MC 26.1.2 jar and/or extra mod jars; WARNS only):
  * Item / enchantment ids referenced by recipe + transformations + costs exist either
    in this mod's own registry namespace, somewhere in the vanilla data jar, or in one of
    the ``--extra-jar`` paths (e.g. a third-party enchantment mod's jar, for ids like
    ``oreenchants:auto_smelt``). Misses are warnings (not failures) to avoid false
    positives on code-only registry entries or ids belonging to mods not present in CI.
  * Non-``minecraft:`` ids referenced from our own JSON (modded item/enchantment ids) are
    reported separately from vanilla ones so a maintainer can see at a glance which
    referenced ids depend on another mod being installed.

Exit code is non-zero if any Tier 1 check fails.

Usage:
  python3 scripts/compat_check.py
  python3 scripts/compat_check.py --mc-jar /path/to/minecraft-extracted_server.jar
  python3 scripts/compat_check.py --extra-jar /path/to/some-other-mod.jar [--extra-jar ...]
"""

from __future__ import annotations

import argparse
import glob
import json
import os
import re
import sys
import zipfile

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_ROOT = os.path.join(REPO, "src", "main", "resources", "data")
NAMESPACE = "chiseled_enchanting_table"

# Modern (singular) -> legacy (plural) directory names for 1.21+/26.x data packs.
SINGULAR_DIRS = {
    "loot_table": "loot_tables",
    "recipe": "recipes",
    "advancement": "advancements",
}
# tag subfolders also singularised: tags/block (not tags/blocks), tags/item, etc.

errors: list[str] = []
warnings: list[str] = []


def err(msg: str) -> None:
    errors.append(msg)


def warn(msg: str) -> None:
    warnings.append(msg)


# --------------------------------------------------------------------------- #
# Tier 1
# --------------------------------------------------------------------------- #

def check_json_parses() -> None:
    for path in glob.glob(os.path.join(REPO, "src", "**", "*.json"), recursive=True):
        try:
            with open(path, encoding="utf-8") as fh:
                json.load(fh)
        except Exception as exc:  # noqa: BLE001
            err(f"JSON parse failed: {os.path.relpath(path, REPO)}: {exc}")


def check_datapack_dir_naming() -> None:
    if not os.path.isdir(DATA_ROOT):
        err(f"missing data root: {DATA_ROOT}")
        return
    for ns in os.listdir(DATA_ROOT):
        ns_dir = os.path.join(DATA_ROOT, ns)
        if not os.path.isdir(ns_dir):
            continue
        for legacy in SINGULAR_DIRS.values():
            legacy_path = os.path.join(ns_dir, legacy)
            if os.path.isdir(legacy_path):
                singular = next(s for s, p in SINGULAR_DIRS.items() if p == legacy)
                err(
                    f"legacy data-pack dir '{ns}/{legacy}/' found; MC 26.1.2 expects "
                    f"'{ns}/{singular}/' (singular). Files here are silently ignored."
                )
        # tags: tags/block not tags/blocks, tags/item not tags/items
        tags_dir = os.path.join(ns_dir, "tags")
        for bad in ("blocks", "items", "entity_types", "fluids", "game_events"):
            if os.path.isdir(os.path.join(tags_dir, bad)):
                err(f"legacy tag dir '{ns}/tags/{bad}/' found; use singular form.")


def iter_block_loot_tables():
    for ns in os.listdir(DATA_ROOT) if os.path.isdir(DATA_ROOT) else []:
        blocks_dir = os.path.join(DATA_ROOT, ns, "loot_table", "blocks")
        if os.path.isdir(blocks_dir):
            for path in glob.glob(os.path.join(blocks_dir, "*.json")):
                yield ns, path


def check_block_loot_tables_drop_something() -> None:
    found_any = False
    for ns, path in iter_block_loot_tables():
        found_any = True
        rel = os.path.relpath(path, REPO)
        try:
            with open(path, encoding="utf-8") as fh:
                data = json.load(fh)
        except Exception:  # already reported by parse check
            continue
        pools = data.get("pools") or []
        if not pools:
            err(f"block loot table has empty/missing pools (drops nothing): {rel}")
            continue
        has_entry = any(p.get("entries") for p in pools)
        if not has_entry:
            err(f"block loot table pools have no entries (drops nothing): {rel}")
    if not found_any:
        warn("no block loot tables found under any '<ns>/loot_table/blocks/'")


def check_transformation_json_matches_java() -> None:
    """The item_transformations.json must mirror the Java built-in fallback so a missing
    datapack file and the bundled file behave identically."""
    json_path = os.path.join(
        DATA_ROOT, NAMESPACE, NAMESPACE, "item_transformations.json"
    )
    java_path = os.path.join(
        REPO, "src", "main", "java", "chiseled_enchanting_table", "data",
        "ChiseledEnchantingTableData.java",
    )
    if not os.path.isfile(json_path) or not os.path.isfile(java_path):
        warn("could not locate both transformation JSON and Java fallback to compare")
        return
    try:
        with open(json_path, encoding="utf-8") as fh:
            json_values = {v["id"]: _norm_transform(v) for v in json.load(fh)["values"]}
    except Exception as exc:  # noqa: BLE001
        err(f"failed reading transformation JSON: {exc}")
        return

    with open(java_path, encoding="utf-8") as fh:
        java_src = fh.read()
    # Pull every brace-object that looks like a transformation out of the embedded
    # text block (lines containing '"input"' and '"output"').
    java_values: dict[str, dict] = {}
    for line in java_src.splitlines():
        if '"input"' in line and '"output"' in line and '"id"' in line:
            snippet = line.strip().rstrip(",")
            try:
                obj = json.loads(snippet)
            except Exception:
                continue
            java_values[obj["id"]] = _norm_transform(obj)

    if not java_values:
        warn("no transformation objects parsed from Java fallback; skipping drift check")
        return

    if set(json_values) != set(java_values):
        err(
            "transformation id sets differ between JSON and Java fallback: "
            f"JSON={sorted(json_values)} JAVA={sorted(java_values)}"
        )
    for tid in set(json_values) & set(java_values):
        if json_values[tid] != java_values[tid]:
            err(
                f"transformation '{tid}' differs between JSON and Java fallback:\n"
                f"    JSON={json_values[tid]}\n    JAVA={java_values[tid]}"
            )


def _norm_transform(v: dict) -> dict:
    """Normalise the fields we care about for drift comparison."""
    return {
        "input": v.get("input"),
        "output": v.get("output"),
        "level": v.get("level", 1),
        "xp_cost": v.get("xp_cost", 0),
        "primary_cost": v.get("primary_cost"),
        "additional_costs": v.get("additional_costs", []),
    }


# A resource location is "[namespace:]path", namespace/path each [a-z0-9_.-/].
_RESOURCE_LOCATION_RE = re.compile(r"^(?:[a-z0-9_.-]+:)?[a-z0-9_./-]+$")


def check_default_enchantment_tags_well_formed() -> None:
    """Validate the `tags` extension in default_enchantments.json (the cross-mod compatibility
    hook: any enchantment mod that tags its enchantments with one of these is auto-included)."""
    path = os.path.join(DATA_ROOT, NAMESPACE, NAMESPACE, "default_enchantments.json")
    if not os.path.isfile(path):
        return
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception:
        return  # already reported by check_json_parses
    tags = data.get("tags")
    if tags is None:
        return
    if not isinstance(tags, list):
        err(f"default_enchantments.json: 'tags' must be a list, got {type(tags).__name__}")
        return
    for i, entry in enumerate(tags):
        if not isinstance(entry, dict) or "tag" not in entry:
            err(f"default_enchantments.json: tags[{i}] must be an object with a 'tag' field")
            continue
        raw_tag = entry["tag"]
        tag_id = raw_tag[1:] if isinstance(raw_tag, str) and raw_tag.startswith("#") else raw_tag
        if not isinstance(tag_id, str) or not _RESOURCE_LOCATION_RE.match(tag_id):
            err(f"default_enchantments.json: tags[{i}].tag is not a valid resource location: {raw_tag!r}")
        level = entry.get("level", 1)
        if not isinstance(level, int) or level < 1:
            err(f"default_enchantments.json: tags[{i}].level must be a positive integer, got {level!r}")


# --------------------------------------------------------------------------- #
# Tier 2 (best-effort id existence against the MC jar and/or third-party mod jars)
# --------------------------------------------------------------------------- #

# Matches any "namespace:path" resource location (not just minecraft:), so ids referencing a
# third-party enchantment/item mod (e.g. "oreenchants:auto_smelt") are picked up too. The
# namespace-only tag prefix ("#namespace:path") is handled by the caller stripping the "#".
ID_RE = re.compile(r"\"#?([a-z0-9_.-]+:[a-z0-9_./-]+)\"")


def collect_referenced_ids() -> set[str]:
    """Ids referenced as *values* (item ids, enchantment ids) — not tag references, which are
    file-path lookups and validated separately by `check_referenced_tags_exist`."""
    ids: set[str] = set()
    targets = [
        os.path.join(DATA_ROOT, NAMESPACE, "recipe", "chiseled_enchanting_table.json"),
        os.path.join(DATA_ROOT, NAMESPACE, NAMESPACE, "item_transformations.json"),
        os.path.join(DATA_ROOT, NAMESPACE, NAMESPACE, "enchantment_costs.json"),
    ]
    for path in targets:
        if os.path.isfile(path):
            with open(path, encoding="utf-8") as fh:
                ids |= set(ID_RE.findall(fh.read()))

    # default_enchantments.json's `values` entries are ids; its `tags` entries are tag references
    # (file-path lookups), not ids, so pull just the `values` half here.
    default_path = os.path.join(DATA_ROOT, NAMESPACE, NAMESPACE, "default_enchantments.json")
    if os.path.isfile(default_path):
        try:
            with open(default_path, encoding="utf-8") as fh:
                data = json.load(fh)
            for entry in data.get("values", []):
                if isinstance(entry, dict) and isinstance(entry.get("enchantment"), str):
                    ids.add(entry["enchantment"])
        except Exception:
            pass  # already reported by check_json_parses
    return ids


def collect_referenced_tags() -> set[str]:
    """Tag ids referenced from `default_enchantments.json`'s `tags` array, normalised to
    'namespace:path' (leading '#' stripped, default namespace added if missing)."""
    tags: set[str] = set()
    path = os.path.join(DATA_ROOT, NAMESPACE, NAMESPACE, "default_enchantments.json")
    if not os.path.isfile(path):
        return tags
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception:
        return tags
    for entry in data.get("tags", []) or []:
        if not isinstance(entry, dict):
            continue
        raw = entry.get("tag")
        if not isinstance(raw, str):
            continue
        tag_id = raw[1:] if raw.startswith("#") else raw
        tags.add(tag_id if ":" in tag_id else f"minecraft:{tag_id}")
    return tags


def check_referenced_tags_exist(mc_jar: str | None, extra_jars: list[str]) -> None:
    """Tags are file-path lookups (data/<ns>/tags/enchantment/<path>.json), not ids that appear as
    values elsewhere, so they need their own existence check distinct from `check_ids_exist`."""
    tags = collect_referenced_tags()
    if not tags:
        return
    jars = ([mc_jar] if mc_jar else []) + list(extra_jars)
    if not jars:
        warn("no MC jar or --extra-jar available; skipping referenced-tag existence check (Tier 2)")
        return
    for tag in sorted(tags):
        namespace, _, path = tag.partition(":")
        rel = f"data/{namespace}/tags/enchantment/{path}.json"
        found = False
        for jar in jars:
            try:
                with zipfile.ZipFile(jar) as zf:
                    if rel in zf.namelist():
                        found = True
                        break
            except Exception:
                continue
        if not found:
            warn(f"referenced tag '#{tag}' not found as '{rel}' in vanilla jar or any --extra-jar (verify it exists)")


def collect_vanilla_ids(mc_jar: str) -> set[str]:
    ids: set[str] = set()
    with zipfile.ZipFile(mc_jar) as zf:
        for name in zf.namelist():
            if name.endswith(".json") and name.startswith("data/minecraft/"):
                try:
                    ids |= set(ID_RE.findall(zf.read(name).decode("utf-8")))
                except Exception:
                    continue
    return ids


def collect_jar_ids(jar_path: str) -> set[str]:
    """Collect ids referenced anywhere in a mod jar's data/assets JSON (best-effort: works for any
    mod jar, e.g. a third-party enchantment mod, so its enchantment/item ids can be verified to
    exist when cross-checking our own JSON references to them)."""
    ids: set[str] = set()
    try:
        with zipfile.ZipFile(jar_path) as zf:
            for name in zf.namelist():
                if name.endswith(".json") and (name.startswith("data/") or name.startswith("assets/")):
                    try:
                        ids |= set(ID_RE.findall(zf.read(name).decode("utf-8")))
                    except Exception:
                        continue
    except Exception as exc:  # noqa: BLE001
        warn(f"could not read extra jar '{jar_path}' for Tier 2 checks: {exc}")
    return ids


def find_mc_jar(explicit: str | None) -> str | None:
    if explicit and os.path.isfile(explicit):
        return explicit
    home = os.path.expanduser("~")
    for cand in (
        os.path.join(home, ".gradle", "caches", "fabric-loom", "26.1.2", "minecraft-extracted_server.jar"),
        os.path.join(home, ".gradle", "caches", "fabric-loom", "26.1.2", "minecraft-common.jar"),
    ):
        if os.path.isfile(cand):
            return cand
    return None


def check_ids_exist(mc_jar: str | None, extra_jars: list[str]) -> None:
    referenced = collect_referenced_ids()
    if not referenced:
        return

    own_namespace_ids = {rid for rid in referenced if rid.startswith(f"{NAMESPACE}:")}
    modded_ids = {
        rid for rid in referenced
        if not rid.startswith("minecraft:") and not rid.startswith(f"{NAMESPACE}:")
    }
    if modded_ids:
        # Not an error: these are cross-mod-compatibility references (e.g. a third-party
        # enchantment/item id used in a cost or transformation entry). Surfacing them
        # separately makes it obvious which referenced ids require another mod to be
        # installed, instead of silently mixing them in with vanilla-only references.
        warn(
            "JSON references non-vanilla, non-self id(s) (require the owning mod to be "
            f"installed): {sorted(modded_ids)}"
        )

    known: set[str] = set()
    if mc_jar:
        known |= collect_vanilla_ids(mc_jar)
    else:
        warn("MC 26.1.2 jar not found; skipping vanilla id existence check (Tier 2)")
    for extra_jar in extra_jars:
        known |= collect_jar_ids(extra_jar)

    if not mc_jar and not extra_jars:
        return

    for rid in sorted(referenced - own_namespace_ids):
        if rid not in known:
            # Items/enchantments defined only in code (no data reference), or belonging to a
            # mod not passed via --extra-jar, may legitimately be absent here, so this is a
            # warning, not an error.
            warn(f"referenced id '{rid}' not seen in vanilla data jar or any --extra-jar (verify it exists)")


# --------------------------------------------------------------------------- #

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mc-jar", help="path to the MC 26.1.2 extracted jar for Tier 2 checks")
    parser.add_argument(
        "--extra-jar",
        action="append",
        default=[],
        help="path to a third-party mod jar to also check referenced ids against "
        "(repeatable; e.g. an enchantment-adding mod jar referenced from cost/transformation JSON)",
    )
    args = parser.parse_args()

    check_json_parses()
    check_datapack_dir_naming()
    check_block_loot_tables_drop_something()
    check_transformation_json_matches_java()
    check_default_enchantment_tags_well_formed()
    mc_jar = find_mc_jar(args.mc_jar)
    check_ids_exist(mc_jar, args.extra_jar)
    check_referenced_tags_exist(mc_jar, args.extra_jar)

    for w in warnings:
        print(f"WARN: {w}")
    for e in errors:
        print(f"FAIL: {e}")

    if errors:
        print(f"\ncompat_check: FAILED ({len(errors)} error(s), {len(warnings)} warning(s))")
        return 1
    print(f"\ncompat_check: PASS ({len(warnings)} warning(s))")
    return 0


if __name__ == "__main__":
    sys.exit(main())
