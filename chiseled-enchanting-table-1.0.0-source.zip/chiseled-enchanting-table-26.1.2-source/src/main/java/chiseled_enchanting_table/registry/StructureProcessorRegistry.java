package chiseled_enchanting_table.registry;

public class StructureProcessorRegistry {
    public static void init() {
        // TODO P3: restore BookshelfReplacerProcessor registration after structure processor API migration.
    }
}
