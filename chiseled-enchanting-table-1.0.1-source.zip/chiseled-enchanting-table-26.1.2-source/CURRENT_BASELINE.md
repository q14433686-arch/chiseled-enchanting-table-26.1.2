# Current Baseline

> **Unofficial community port.** This repository is an unofficial community port of
> [Sacramentix/chiseled-enchanting-table](https://github.com/Sacramentix/chiseled-enchanting-table)
> to Minecraft **26.1.2** on Fabric. It is **not affiliated with, endorsed by, or maintained by
> the original author**. All credit for the original mod design and assets belongs to Sacramentix
> (MIT licensed); this port only updates the code/data to the 26.1.2 toolchain.

**Date:** 2026-07-01
**Minecraft Version:** 26.1.2
**Fabric Loader:** 0.19.3
**Fabric API:** 0.151.0+26.1.2
**Gradle:** 9.4.1
**Loom:** 1.16.3
**Java:** 25.0.3 (system-wide `/usr/lib/jvm/java-25-openjdk-amd64`; on a fresh sandbox install via
`apt-get install -y openjdk-25-jdk-headless`)
**Mod Version:** `1.0.1`  *(unofficial-port versioning, see "Versioning" below)*

## Versioning

Starting with this release, the unofficial port uses a clean SemVer `MAJOR.MINOR.PATCH` line
beginning at **`1.0.0`** instead of the previous `0.2.3+26.1.2-pNN` upstream-derived scheme.

- `1.0.0` is the first stable, publishable build of the unofficial 26.1.2 port.
- The Minecraft target version (`26.1.2`) is no longer baked into `mod_version`; it is declared
  via `depends.minecraft` in `fabric.mod.json` and via the publish workflow's `MINECRAFT_VERSION`.
- The old internal `pNN` round labels (P1-P19) are kept as **historical entries inside
  `CHANGELOG.md` and `docs/reports/PORTING_26_1_2_PNN_*.md`** because they are an accurate record
  of how the port was built up. They no longer correspond to a `mod_version` value.
- Future iterations on top of `1.0.0` should bump SemVer normally (e.g. `1.0.1` for a fix,
  `1.1.0` for a backwards-compatible feature).

## Current Source-Truth Snapshot (what the code/data actually contains today)

### Build / packaging
- `gradle.properties`: `mod_version=1.0.1`, `minecraft_version=26.1.2`,
  `loader_version=0.19.3`, `fabric_version=0.151.0+26.1.2`.
- `src/main/resources/fabric.mod.json`:
  - `version: "${version}"` (substituted by Loom to `1.0.1`).
  - `name`: `Chiseled Enchanting Table (Unofficial 26.1.2 Port)`.
  - `description`: explicitly states this is an unofficial port and not affiliated with the
    original author.
  - `authors`: original `Sacramentix` plus the unofficial-port maintainer `q14433686-arch`.
  - `contact.sources`: this port's GitHub; `contact.homepage`: original upstream.
  - `depends`: `fabricloader >=0.19.3`, `minecraft 26.1.2`, `java >=25`, `fabric-api *`.
  - `mixins: ["chiseled-enchanting-table-port.mixins.json"]` — the port config declares the four
    structure mixins under `chiseled_enchanting_table.mixin.structure.*`.
  - `custom.chiseled_enchanting_table:port_notes`: documents the unofficial-port status and the
    current mixin/loot/structure boundary. Refresh planned once the fill outcome is live-verified
    (currently still worded around the gated-off skeleton phase).
- `.github/workflows/publish.yml`: `MINECRAFT_VERSION: 26.1.2`, `JAVA_VERSION: 25`,
  `VERSION: 1.0.1`, `RELEASE_NAME: Chiseled Enchanting Table 1.0.1 (Unofficial 26.1.2 Port)`.

### Source layout (post-P17 package split, plus mechanics packages added at 1.0.0)
- `chiseled_enchanting_table.block.*` — `ChiseledEnchantingTableBlock`,
  `ChiseledEnchantingTableBlockEntity`, `FloatingBook`, `ChiseledBookshelfTick`
  (the legacy mixed `chiseledEnchantingTable` package has been retired).
- `chiseled_enchanting_table.data.ChiseledEnchantingTableData` — server-data reload listener that
  loads JSON-driven default unlocks, costs, transformations.
- `chiseled_enchanting_table.mechanics.enchanting.EnchantmentApplication` and
  `chiseled_enchanting_table.mechanics.transformation.ItemTransformationApplication`.
- `chiseled_enchanting_table.mechanics.loot.EnchantedBookLootInjector` +
  `RemoveEnchantedBooksFunction` — chest-loot injection driven by `loot_injections.json`.
- `chiseled_enchanting_table.mechanics.structure.{BookshelfReplacerProcessor, BookshelfBookFiller}`
  — structure bookshelf replacement processor + weighted book fill; called from **5 mixins**
  under `chiseled_enchanting_table.mixin.structure.*` (4 injectors + 1 accessor).
  `REPLACEMENT_ENABLED = true`. Two-phase pipeline:
  - **Template-pool path** (villages / mansions / ancient cities): `processBlock` swaps
    `BOOKSHELF` → empty `CHISELED_BOOKSHELF` at placement, then `finalizeProcessing` uses a
    `ServerLevelAccessor` to resolve the dynamic enchantment registry and fill the 6 slots.
  - **Programmatic path** (stronghold libraries): `StructurePieceMarkMixin` (uses
    `StructurePieceAccessor` invoker to convert piece-local → world coords via vanilla
    `getWorldPos`) marks the position; `LevelChunkPostProcessMixin` at `@At("HEAD")` iterates the
    still-full `postProcessing` lists using vanilla's own
    `ProtoChunk.unpackOffsetCoordinates(short, int sectionY, ChunkPos)` and delegates to
    `BookshelfReplacerProcessor.postProcessBookshelf`, which reuses the same filler.
- `chiseled_enchanting_table.menu.*` — `ChiseledEnchantingTableScreenHandler`,
  `ChiseledEnchantingMenuPayloads` (`OptionType`, `TransformationDisplay`,
  `AvailableEnchantmentPayload`, `ApplyEnchantmentPayload`), `AvailableOption`
  (typed enchantment vs. transformation).
- `chiseled_enchanting_table.registry.*` — `BlockRegistry`, `EntityRegistry`,
  `ScreenHandlerRegistry`, `StructureProcessorRegistry`.
- `chiseled_enchanting_table.utils.*` — `Advancement`, `BlockPosStream`, `EnchantmentFinder`,
  `EnchantmentWithLevel`, `InventoryUtils`.
- Client (`src/client/java`): `ChiseledEnchantingTableClient`, `ChiseledEnchantingTableScreen`,
  `EnchantementListWidget`, `gui.row.*` (`RowRenderSupport`, `EnchantmentRowRenderer`,
  `TransformationRowRenderer`).

### Data / JSON
- `data/chiseled_enchanting_table/chiseled_enchanting_table/default_enchantments.json` —
  `values` (small list of explicitly-unlocked vanilla treasure enchantments) + `tags`
  (default `#minecraft:non_treasure`, level 1) for cross-mod tag-driven unlocks.
- `data/chiseled_enchanting_table/chiseled_enchanting_table/enchantment_costs.json` — per-level
  item + XP costs, with the `scute` -> `turtle_scute` fix.
- `data/chiseled_enchanting_table/chiseled_enchanting_table/item_transformations.json` — JSON
  source of truth for item transformations; the compat check enforces no drift with the Java
  fallback table.
- `data/chiseled_enchanting_table/chiseled_enchanting_table/loot_injections.json` — enchanted-book
  injections into 41 vanilla chest / archaeology loot tables (196 sub-entries). Auto-derived from
  upstream `ReworkEnchantedBookChestLoot.java` by `scripts/import_upstream_loot.py`.
- `data/chiseled_enchanting_table/chiseled_enchanting_table/bookshelf_book_pool.json` — v2 fill
  rules for structure-placed chiseled bookshelves: `book_count = { min: 3, max: 5 }`,
  `enchanted_book_probability = 0.03`, and an `enchanted_book_selection` block that describes how
  the enchanted-book candidate pool from `loot_injections.json` is weighted (base weight ×
  live-registry `Enchantment.getWeight()` × `maxLevelWeightRatio^relativeLevel` where
  `relativeLevel = (level-1)/(maxLevel-1)`). Single source of truth for "which enchanted books
  appear in world content" is `loot_injections.json`; this file only configures how often / how
  weighted.
- Block loot table at the modern singular path
  `data/chiseled_enchanting_table/loot_table/blocks/chiseled_enchanting_table.json` (drops-self,
  with `CopyName` from the block entity). The legacy plural `loot_tables/blocks/` path is gone.

### Tooling
- `scripts/compat_check.py` — Tier 1 (offline, fails the build) covers singular-dir convention,
  no stale plural dirs, non-empty block-loot pools, all-JSON parses, JSON/Java transformation
  drift, and `default_enchantments.json` `tags` schema. Tier 2 (best-effort, warn-only) checks
  id existence against `--mc-jar` and/or `--extra-jar` paths.

### Active Temporary Boundaries
- Main-source exclusions still parked in `build.gradle`:
  - `chiseled_enchanting_table.integration.*` (third-party mod integration; port later as an
    opt-in layer)
  - `chiseled_enchanting_table.mixin.enchanting_table.*`, `mixin.anvil.*`, `mixin.chiseled_bookshelf.*`,
    `mixin.accessor.*` (legacy upstream mixins that need their own 26.1.2 mapping pass; not
    re-verified yet)
  - Legacy `modifyChestLootTable/**`, `structureProcessor/**`, `utils/ChiseledBookshelfLootTable`
    (fully superseded by the JSON-driven injector + `mechanics/structure/*`)
  - `block/ChiseledBookshelfTick` (enchant particle/sound over a chiseled bookshelf; still deferred)
- Runtime feature gaps:
  - Shelf-power formula final balancing.
  - Full live-client gameplay validation of the actual bookshelf fills in villages / mansions /
    strongholds / ancient cities is still pending (mixin call sites are verified; the fill
    outcome — visible books in the shelves — is what needs the next round of live testing).

### Release artifacts (this round)
Staged under `release_output/chiseled_enchanting_table_1_0_1/`:
- `chiseled-enchanting-table-1.0.1.jar` (in-jar icon matches the 256×256 cover)
- `chiseled-enchanting-table-1.0.1-sources.jar`
- `chiseled-enchanting-table-1.0.1-source.zip` (working-tree zip; excludes
  `.git/`, `.gradle/`, `build/`, `release_output/`).
- `cover-icon-256.png` — 256×256 RGBA cover icon, ready to upload to Modrinth / CurseForge /
  MC百科 directly.
- `cover-banner.png` — repo root banner, staged alongside for optional gallery use.

The previous `release_output/chiseled_enchanting_table_1_0_0/` directory has been superseded by
the `1_0_1` directory; older `chiseled_enchanting_table_26_1_2_pNN` directories from the pre-1.0
porting rounds were already removed at the 1.0.0 rebrand.

## Verified This Session (2026-07-01)

- `openjdk-25-jdk-headless` installed on the sandbox (default image only ships JDK 11).
- `chmod +x ./gradlew`.
- `python3 scripts/compat_check.py` -> **`PASS (0 warning(s))`** (Tier 2 not exercised — no
  `--mc-jar` / `--extra-jar` provided).
- `./gradlew build --rerun-tasks --stacktrace` -> BUILD SUCCESSFUL.
- Built jar `fabric.mod.json` spot check: `version=1.0.1`, name marked as Unofficial 26.1.2 Port,
  authors include both original and port maintainer, `depends.minecraft=26.1.2`,
  `mixins=["chiseled-enchanting-table-port.mixins.json"]`.

## Client-Only / Live-Game Validation Still Pending

Same as the prior baseline — these require a real MC 26.1.2 + Fabric runtime and were not run in
this headless sandbox: mod-metadata load, block placement, custom menu open, slot/scroll/floating
book renderer, enchanting + transformation application, chiseled-bookshelf scanning, P19 tag-based
cross-mod default unlocks, multiplayer sync beyond payload registration, and mining drop in a
live world. The full list is kept in `docs/reports/CURRENT_AGENT_BRIEF.md`.
