package chiseled_enchanting_table.utils;

import chiseled_enchanting_table.ChiseledEnchantingTable;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class Advancement {
    public static void give(Player player, String name) {
        if (!(player instanceof ServerPlayer serverPlayer)) return;
        var advancement = serverPlayer.level().getServer().getAdvancements().get(ChiseledEnchantingTable.identifier(name));
        if (advancement == null) return;
        var progress = serverPlayer.getAdvancements().getOrStartProgress(advancement);
        if (progress.isDone()) return;
        for (var criterion : progress.getRemainingCriteria()) {
            serverPlayer.getAdvancements().award(advancement, criterion);
        }
    }

    public static void checkAllEnchantBook(Player player, Level level, ItemStack enchantableItem) {
        // TODO P2/P3: restore all-enchantment-book advancement check after enchantment API migration.
    }
}
