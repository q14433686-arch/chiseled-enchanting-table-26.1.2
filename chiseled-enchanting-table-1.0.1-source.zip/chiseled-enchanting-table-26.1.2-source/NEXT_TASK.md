# Next Task: post-1.0.1 backlog

> **Unofficial community port.** All instructions below apply to the unofficial 26.1.2 port
> (this repository). The upstream `Sacramentix/chiseled-enchanting-table` project is not affected
> by this version line.

**Current mod version:** `1.0.1`. See `CURRENT_BASELINE.md` for the currently-shipping
capability boundary and `CHANGELOG.md` for the 1.0.1 fix list. All 1.0.0 live-verification
items and every follow-up bug reported through the 1.0.1 iteration cycle
(book-path UI, enchant-book probability, shelf-facing v2/v3, XP-as-points, stronghold
mark-and-post-process pipeline) are now **closed**.

## How to build 1.0.1 from a fresh clone

Same recipe as the previous release; the source tree is 100% Gradle + Loom + Fabric API +
Java 25:

```bash
sudo apt-get install -y openjdk-25-jdk-headless     # if Java 25 isn't already on PATH
chmod +x ./gradlew
python3 scripts/compat_check.py                     # offline data-pack sanity (Tier 1 must pass)
JAVA_HOME=/usr/lib/jvm/java-25-openjdk-amd64 ./gradlew --no-daemon --max-workers=1 \
    -Dorg.gradle.jvmargs='-Xmx1024m -Dfile.encoding=UTF-8' build --rerun-tasks --stacktrace
```

Artefacts land in `build/libs/`; the maintainer copies them to
`release_output/chiseled_enchanting_table_1_0_1/` for distribution.

## Open items (roughly in priority order)

### A. Multi-slot cost panel (last big UI decoupling backlog item)

Currently the menu has two container slots: `ENCHANTABLE_SLOT` and `COST_SLOT`. Multi-item costs
(both `enchantment_costs.json` `additional_costs` and `item_transformations.json`
`additional_costs`) are consumed silently from the player's main inventory when the enchant is
applied. That's easy to miss (players don't see what's about to be spent) and it interacts
awkwardly with mods that lock inventory slots. The proper fix is a dedicated multi-slot cost
panel in the menu, similar to what smithing tables show.

Scope: menu layout, `AbstractContainerMenu` slot registration, `quickMoveStack` behaviour,
network protocol (currently `AvailableEnchantmentPayload` only carries a flat cost tuple),
client renderer, and a live-test pass. This is the largest remaining UI change and should be
its own release (probably `1.1.0`).

### B. Restore the parked legacy mixins one at a time

`build.gradle` still excludes four upstream mixin folders that haven't been re-verified for
26.1.2 signatures yet:

- `mixin/enchanting_table/**` — "no more same-level enchant-book combine at an anvil"
  (upstream's original balance change). Currently vanilla-anvil combining still works.
- `mixin/anvil/**` — `RemoveEnchantMerge`, `RemoveXpCostScaling`. Vanilla anvil XP behaviour
  is currently unchanged from vanilla.
- `mixin/chiseled_bookshelf/**` — `AddRandomTick` (enables the ambient particle/sound over a
  chiseled bookshelf holding an enchanted book).
- `mixin/accessor/**` — `ItemAccessor` (used by the above; kept parked with them).

Each is small in isolation; re-enabling one at a time with mapping verification (using the same
approach as the successful structure mixins in 1.0.0) is the safest path.

### C. Third-party mod integration layer

`chiseled_enchanting_table.integration.*` (Colorful Books integration; possibly Bookshelf
Inspector display hooks) is still excluded from the compile slice. Should ship as an opt-in
sub-package so it only loads when the target mod is present.

### D. Data-pack extension coverage

Cross-check that every data file under
`src/main/resources/data/chiseled_enchanting_table/chiseled_enchanting_table/` is documented in
[`docs/EXTENDING.md`](docs/EXTENDING.md) and covered by a Tier-1 schema check in
`scripts/compat_check.py`. As of 1.0.1 all five (default_enchantments, enchantment_costs,
item_transformations, loot_injections, bookshelf_book_pool) are covered — keep it that way when
adding new data files.

## Validation required after any change

- `python3 scripts/compat_check.py` (Tier 1 must pass; pass `--extra-jar <path>` when testing
  alongside a specific third-party mod to also exercise Tier 2 id-existence coverage for its
  ids).
- JSON syntax validation for changed JSON files.
- `./gradlew build --rerun-tasks`.
- Jar metadata / resource spot check: `version` matches `gradle.properties`, name still marked
  Unofficial, `mixins` list matches the intended config.
- Refresh `release_output/chiseled_enchanting_table_<version>/` if source / resource / jar bytes
  changed. Directory name follows `chiseled_enchanting_table_<version with _ for .>`, e.g.
  `chiseled_enchanting_table_1_0_1` for `1.0.1`, `chiseled_enchanting_table_1_1_0` for `1.1.0`.
- If the source-of-truth for an in-game gameplay tuning changes (probabilities, cost formulas,
  book-count ranges, ...), update the "Concrete expected outcomes" table in `NEXT_TASK.md` so
  the next live-test round has an unambiguous target.
- Update `CHANGELOG.md` (top of file, `[Unreleased]` block) with the visible change; when
  releasing, rename `[Unreleased]` to the new version and, if there are already two versions
  in `CHANGELOG.md`, roll the oldest into `docs/CHANGELOG_HISTORY.md` verbatim.
