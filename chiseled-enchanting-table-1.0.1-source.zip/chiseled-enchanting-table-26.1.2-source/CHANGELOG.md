# Changelog

> **Unofficial community port.** This changelog covers the unofficial 26.1.2 port maintained at
> `q14433686-arch/chiseled-enchanting-table-26.1.2-source`. It is not affiliated with or endorsed
> by the original author (Sacramentix). The original mod remains MIT-licensed; this port re-uses
> the original code/assets under that licence and updates them to the 26.1.2 toolchain.

Only the current release and one previous release are kept here. Every entry from `1.0.0` and
earlier (including the pre-`1.0.0` P1-P19 porting rounds and the rename/rebrand work) is archived
verbatim under [`docs/CHANGELOG_HISTORY.md`](docs/CHANGELOG_HISTORY.md) so this file stays
readable.

## [1.0.1] - 2026-07-01

### Fix: enchant-from-book UI was inert for out-of-unlocked-set enchantments
User report: with a Wind Burst III enchanted book in the cost slot and a mace in the enchantable
slot, the option row appeared in the list but clicking it did nothing (the row rendered as
"cost not met"). Wind Burst is loot-only (not in `#minecraft:non_treasure`) so it never appears
in the unlocked set; the only way to apply it is the enchant-transfer-from-book path.

Root cause was purely client-side: `EnchantementListWidget.EnchantUiEntry.itemCostConditionMet`
returned `false` whenever the synthetic `cost` was empty, and the book path deliberately sets
`cost = ItemStack.EMPTY` (the book itself is the payment, so we don't want to also charge
material items). The empty check happened first, so book-path rows always failed the cost
check and the click was ignored.

Two-line fix in the same method:
- Waive the item-cost check outright when the cost slot holds an `ENCHANTED_BOOK`.
- Also blank out `additional_costs` in the entry constructor when the cost slot holds a book,
  so the renderer stops showing "additional cost" pips that would never be consumed.

Server-side `EnchantmentApplication.applyFromBook` was already correct — it checks
`canEnchant(enchantable_item)` for the target, transfers the enchantment, and turns the book
back into a plain book when its last enchantment is stripped. No server change needed.

Concrete effect: with a Wind Burst III book in the cost slot and a mace in the enchantable
slot, clicking the row now applies Wind Burst III to the mace and consumes the book. Same for
any other loot-only enchantment (Mending, Silk Touch when not unlocked yet, Swift Sneak, etc.)
that a player might legitimately have as a book but not have unlocked at the table.

- `compat_check.py` → PASS.
- `./gradlew build --rerun-tasks` → BUILD SUCCESSFUL.
- Release output refreshed.

### Fix: XP deduction now vanilla-anvil-style (points, not raw levels)
User feedback: the previous implementation called `player.giveExperienceLevels(-N)`, which
literally decrements the level counter by N — treating "one level" as a flat unit of currency
regardless of what that level was worth in XP points. Vanilla anvil / enchanting-table cost N
levels means "consume the XP that fills the top N levels of your current bar", which is much
more expensive at higher levels (where each level is worth many more XP points). The old
behaviour under-charged low-level players and over-charged high-level ones for the exact same
service.

Added `mechanics.enchanting.XpCostConversion.pointsForLevelCost(player, levelCost)` that
computes the actual XP-point deduction from the vanilla level curve (`2·level+7` / `5·level-38`
/ `9·level-158` breakpoints at levels 16 and 31). `ChiseledEnchantingTableScreenHandler.applyEnchantementCondition`
now calls `giveExperiencePoints(-xpPointsToDeduct)` instead of `giveExperienceLevels(-N)`. The
existence-check (`experienceLevel < xp_level_cost`) is unchanged — that's the affordability
gate, which is still "does the player have at least N levels available", and it still passes
whenever the new point-based deduction would succeed.

Concrete effect: a level-30 player paying a 5-level cost now loses XP equivalent to filling
levels 26-30 (~365 points, ending at level 25); a level-50 player paying the same 5-level cost
loses ~635 points (ending at level 45). This is what "cost 5 levels" always meant in vanilla.
The book-based enchant path (`EnchantmentApplication.applyFromBook`) was already XP-free by
design and remains so.

- `compat_check.py` → PASS (0 warnings).
- `./gradlew build --rerun-tasks` → BUILD SUCCESSFUL (12s).
- Release output refreshed.

### Balance: enchanted book probability 20% -> 3%, level penalty now relative-to-max
User feedback: enchanted books were still too common; and the previous per-numeric-level falloff
was unfair to enchantments that don't have high level tiers (Mending / Silk Touch / Infinity
never rolled a level penalty at all, while Sharpness V and Blast Protection V got the same
`0.5^4` treatment even though the latter is that enchantment's *ceiling* whereas V is Sharpness'
ceiling too).

Two changes in `bookshelf_book_pool.json` + one in the filler math:
- `enchanted_book_probability`: `0.20` → **`0.03`** (per user request).
- `enchanted_book_selection.level_falloff` (per-numeric-level) → `max_level_weight_ratio`
  (per-relative-level, default `0.1`). New formula:
  `weight *= maxLevelWeightRatio ^ relativeLevel` where
  `relativeLevel = (level-1)/(maxLevel-1)` for `maxLevel > 1`, else `0`. Effect: a book that's
  at its enchantment's max level always eats the same `^1` penalty regardless of the numeric
  level; a level-1 book never eats a penalty; single-level enchantments (Mending, Silk Touch,
  Infinity, Curse of Vanishing) never eat a penalty at all. This matches the user's intent of
  "penalise relative to how strong the book is for its own enchantment".
- Loader accepts the old `level_falloff` field name during transition (maps it to an approximate
  new-schema value assuming max level ≈ 4) so a stale data pack doesn't silently revert to the
  fallback; `scripts/compat_check.py` emits a deprecation warning for the old name.

- `compat_check.py` → PASS (0 warnings).
- `./gradlew build --rerun-tasks` → BUILD SUCCESSFUL (12s).
- Release output refreshed.

### Fix: shelf facing v3 (score-based, replaces v2's hard back-must-be-sturdy rule)
User's second-round facing report:
1. Shelf with a **chest** behind it fell through to random-looking default rotation.
2. Shelf in stronghold rooms with **front + back both open and one perpendicular side blocked**
   ended up back-to-the-side-block instead of matching neighbouring shelves' along-corridor axis.

Root causes:
1. v2's back check used {@code isFaceSturdy}, which returns false for chests, slabs, other
   shelves, stairs, doors, etc. — so a shelf with any of those behind it was rejected on every
   axis and fell back to the incoming block state's default facing (which, under template-pool
   rotation transforms, looked random across pieces).
2. v2's "unambiguous back-to-wall wins over ambiguous" rule was pathologically wrong when the
   only wall was on a perpendicular side: the algorithm dutifully picked "back to the side
   wall" (technically a valid back-to-wall arrangement) instead of noticing that both directions
   on the along-corridor axis were open and that's what the neighbouring shelves in a row would
   have picked.

Rewrote {@code pickFrontFacing} into a score-based ranking (see the class javadoc for the full
rubric). Key change: an **open-axis bonus of +100** dominates every other single signal, so a
shelf with both front and back open on some axis always faces along that axis (fixing Bug 2)
even if a perpendicular direction has a sturdy wall behind (which used to score +10 and win in
v2). Meanwhile a non-sturdy non-air back now scores +6 (up from 0), so chests / slabs / other
shelves behind the shelf no longer force a fall-through to the default (fixing Bug 1). Fixed
tie-break order (X-axis then Z-axis, negative direction then positive within each axis) keeps a
row of shelves in matching geometry all resolving to the same facing independently.

- `compat_check.py` → PASS (0 warnings).
- `./gradlew build --rerun-tasks` → BUILD SUCCESSFUL (13s).
- Release output refreshed.

### Fix: shelf facing v2 (require back-to-wall, not just "front toward air")
User live-tested the previous facing fix and reported that shelves still had irregular facings
compared to vanilla — "when only one side of the shelf is a block, the facing can be any of the
non-block sides, so shelves floating in a room end up facing arbitrary directions."

Root cause: the old {@code pickFrontFacing} only checked that the chosen front direction was
air. That was too permissive — a free-standing shelf (all four horizontal neighbours are air)
would pick a random air direction and end up facing nothing in particular. Even worse, a shelf
with one wall on one side would pick the *opposite* direction (also air) and stand with its
back to the room rather than against the wall.

Rewrote {@code BookshelfBookFiller.pickFrontFacing} with a two-condition rule per candidate
direction {@code d}:
  1. {@code pos.relative(d)} must be passable (not sturdy on the face toward us) — a player
     would be able to stand there and interact with the shelf.
  2. {@code pos.relative(d.getOpposite())} must be sturdy on the face toward us — the shelf's
     back must be against a wall.

Both use {@link net.minecraft.world.level.block.state.BlockBehaviour.BlockStateBase#isFaceSturdy}
(the same predicate vanilla uses for banners / item frames / other back-to-wall furniture) so
we correctly ignore non-solid or partially-open neighbours like slabs, stairs, glass, doors.

Axes are enumerated in the fixed order X, Z, and within each axis we prefer the arrangement
where **exactly one** direction is valid (that's the unambiguous back-to-wall case, and every
shelf in a row along the same wall will independently arrive at the same answer, which is what
"as regular as vanilla shelves" means). Free-standing shelves (both directions on an axis
valid) fall back to a fixed lower-indexed direction so a row of them is at least consistent.
If no axis yields a valid arrangement (fully buried or all sides passable), the shelf keeps
its incoming default facing rather than being force-corrected into a glitched state.

- `compat_check.py` → PASS.
- `./gradlew build --rerun-tasks` → BUILD SUCCESSFUL.
- Release output refreshed.

### Fix: too few books per shelf, wrong shelf facing (bookshelf_book_pool.json schema v2)
User live-tested the fixed structure pipeline; two issues surfaced:

1. **Books per shelf were much too low** (the old schema's `slot_content_weights.empty=9550000`
   dominated everything else — a shelf that should have 3-5 books effectively rolled empty for
   ~96% of slots). Redesigned the whole slot-fill model:
   - Retired schema v1's `filling_type_weights` + `slot_content_weights` fields (both are now
     Tier-1 rejected by `compat_check.py` with a "use v2 keys instead" error).
   - New v2 schema: `book_count = { min, max }` (default 3-5), `enchanted_book_probability`
     (default 0.20), and an `enchanted_book_selection` block that describes how the enchanted-book
     candidate pool is weighted.
   - New algorithm: pick N in [min, max], pick N distinct slots out of 6, for each book roll the
     enchant probability to decide plain-vs-enchanted, weighted pick from the candidate pool.
   - Enchanted-book weighting is now data-driven along **three** axes multiplicatively:
     `baseWeight × vanillaWeightFactor(getWeight()) × levelFalloff^(level-1)`. Enchantment weight
     (Sharpness=10 vs Silk Touch=1 vs Mending=2) is read live from the registry so it stays right
     across cross-mod content changes and future rebalances; `levelFalloff=0.5` (default) makes a
     level-5 book ~1/16 as common as level 1 with everything else equal.
2. **Shelf facing was fixed** (every generated shelf faced the same default direction). Root
   cause: my `applyToPlacedBookshelf` created the state from `defaultBlockState()` and never set
   FACING. Added `pickFrontFacing(ServerLevel, BlockPos, RandomSource)` that scans the four
   horizontal neighbours (shuffled by positional seed for determinism) and returns the direction
   of the first one that's air — vanilla's `ChiseledBookShelfBlock.FACING` matches the direction
   the shelf's *open front* faces (see `getStateForPlacement`: `FACING = playerDir.getOpposite()`,
   i.e. the shelf back is toward the player). If all four neighbours are solid we keep the
   incoming state's facing (buried-in-wall shelves stay as they were).

Data-model / API changes:
- `ChiseledEnchantingTableData.BookshelfBookPool` record: 12 old fields → 8 new fields
  (`minBooks`, `maxBooks`, `enchantedBookProbability`, `enchantPoolSource`, `useBaseWeight`,
  `useVanillaWeightFactor`, `levelFalloff`, `enchantSets`).
- `BookshelfBookFiller.applyToPlacedBookshelf` rewritten; also switched candidate aggregation
  from "per-book O(N)" to "per-shelf O(N)" so the walk over `loot_injections.json` happens once
  per shelf, not once per book.

- `compat_check.py` → PASS (0 warnings).
- `./gradlew build --rerun-tasks` → BUILD SUCCESSFUL (13s).
- Release output refreshed.

### Fix: stronghold bookshelves were not being replaced
User live-tested the previous round; report was "strongholds not replacing bookshelves, other
structures untested but probably the same". Root-caused to **two silent-but-fatal bugs** in the
mark-and-post-process pipeline that add up to "the mixin fires, but the marks never make it into
the world's real post-processing set":

1. `StructurePieceMarkMixin` was passing the raw `(x, y, z)` args of
   `StructurePiece.placeBlock` straight into a `new BlockPos(x, y, z)`. Those args are
   **piece-local**, not world coordinates — vanilla immediately converts them via the protected
   `getWorldPos(int, int, int)` helper (which also applies the piece's rotation + mirror). Marking
   a random position near (0,0,0) either falls outside the currently-generating chunk (silent no-op)
   or writes to the wrong world coord entirely. Fixed by adding a new `StructurePieceAccessor`
   invoker mixin that exposes `getWorldPos`, and using it inside `StructurePieceMarkMixin` before
   calling `markPosForPostprocessing`. We also freeze the returned `MutableBlockPos` to `immutable()`
   in case vanilla reuses the mutable instance later in the same call.
2. `LevelChunkPostProcessMixin` was injecting at `@At("TAIL")` and hand-decoding the packed shorts
   itself. Both were wrong:
   - **TAIL is too late:** vanilla's `LevelChunk.postProcessGeneration` calls `list.clear()`
     inside its per-section loop as it drains each list. At TAIL the arrays are empty. Changed to
     `@At("HEAD")` so we see the full lists first.
   - **Hand-decode was guessing the wrong bit layout.** Replaced with vanilla's own
     `ProtoChunk.unpackOffsetCoordinates(short packed, int sectionY, ChunkPos)` — this is the same
     static method vanilla itself calls in `postProcessGeneration`, so it's correct-by-construction
     and future-proof against any packing tweak.

Also added the new `StructurePieceAccessor` to `chiseled-enchanting-table-port.mixins.json`.

No `bookshelf_book_pool.json` / `loot_injections.json` content changes. Both filler paths
(`BookshelfReplacerProcessor.finalizeProcessing` for template-pool structures and the fixed
mark-and-post-process pipeline above for programmatic structures like strongholds) now share the
single `BookshelfBookFiller.applyToPlacedBookshelf` enrichment as designed.

- `compat_check.py` → PASS (0 warnings).
- `./gradlew build --rerun-tasks` → BUILD SUCCESSFUL (12s).
- Release output refreshed.

### Structure bookshelf replacement — block-write side switched on
- Flipped `BookshelfReplacerProcessor.REPLACEMENT_ENABLED` to `true` after live-verification
  (user reported all four mixin call sites hit correctly on 26.1.2).
- Implemented `BookshelfBookFiller.applyToPlacedBookshelf(ServerLevel, BlockPos, RandomSource)` —
  the single enrichment path shared by both the template-pool structures (villages / mansions /
  ancient cities via `BookshelfReplacerProcessor.finalizeProcessing`) and the programmatic
  structures (stronghold libraries via `LevelChunkPostProcessMixin` → `postProcessBookshelf`).
- Split the processor into a two-phase pipeline:
  - `processBlock` rewrites `Blocks.BOOKSHELF` → `Blocks.CHISELED_BOOKSHELF` (empty, no NBT) at
    template-placement time. This is the only phase that runs without a `ServerLevel`.
  - `finalizeProcessing` gets a `ServerLevelAccessor`, so it can obtain the dynamic enchantment
    registry via `level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT)` and hand real
    `Holder<Enchantment>` references to `EnchantmentHelper.updateEnchantments(...)`. This is
    where books actually acquire their `STORED_ENCHANTMENTS` component.
- Enchanted books written by the filler carry the same purple "Chiseled Enchanting Table" lore
  stamp as loot-injected books, so `RemoveEnchantedBooksFunction` and player triage both work
  uniformly across the two entry paths.
- Fill uses a positional seed derived from world seed + block position so world generation stays
  deterministic (same world seed → same bookshelf contents at any given coordinate).
- Fixed `loot_injections.json` `minecraft:chests/village_armorer` → `minecraft:chests/village/village_armorer`
  (pre-1.17 path that came in via the auto-import; 26.1.2 uses the sub-path). Also taught
  `scripts/import_upstream_loot.py` to apply the same fix so re-derivation stays clean.
- `compat_check.py` → PASS (0 warnings).
- `./gradlew build --rerun-tasks` → BUILD SUCCESSFUL (12 s).
- Release output refreshed under `release_output/chiseled_enchanting_table_1_0_0/`.

### Structure bookshelf replacement + chest loot injection (feature port from upstream)
- **New feature (data-driven loot injection):** ported upstream's chest / archaeology loot
  injection (upstream `ReworkEnchantedBookChestLoot.java`, ~1475 lines of hardcoded Java) into a
  single JSON table: `data/chiseled_enchanting_table/chiseled_enchanting_table/loot_injections.json`
  (41 injection targets, 196 sub-entries). The Java side is a ~110-line generic executor
  (`mechanics/loot/EnchantedBookLootInjector`) that reads the JSON at
  `LootTableEvents.MODIFY` and appends a purple-lore-stamped enchanted-book pool via vanilla
  `SetEnchantmentsFunction` + `SetLoreFunction`. Per user decision "keep_both", vanilla enchanted
  books in chests are **not** stripped; both the vanilla and the injected books can drop in the
  same chest, distinguishable by the lore stamp.
- **Data-derivation tooling:** `scripts/import_upstream_loot.py` derives the JSON from the
  upstream Java source and is kept in-repo so the derivation is auditable / reproducible.
- **New feature (structure bookshelf replacement — skeleton):** wired up the four upstream mixin
  hooks (`mixin/structure/{StructureTemplatePoolProjectionMixin, StructurePlaceSettingsMixin,
  StructurePieceMarkMixin, LevelChunkPostProcessMixin}`) so `BookshelfReplacerProcessor` is now
  called from all four upstream code paths (template-pool structures like villages / ancient
  cities, direct-placement structures like woodland mansions, and programmatic structures like
  stronghold libraries via the mark-and-post-process pattern). Wired via a new
  `chiseled-enchanting-table-port.mixins.json` (isolated from the legacy upstream mixin config
  name so future upstream-mixin ports can coexist).
- The **actual bookshelf → chiseled-bookshelf block replacement is gated off** by
  `BookshelfReplacerProcessor.REPLACEMENT_ENABLED` (currently `false`); the mixin skeleton logs
  hits so live testing can confirm the four call sites fire in the expected structures before we
  flip the switch and start writing NBT to world chunks.
- **New JSON table (weighted 6-slot fill):**
  `data/chiseled_enchanting_table/chiseled_enchanting_table/bookshelf_book_pool.json` +
  `data.ChiseledEnchantingTableData.BookshelfBookPool` record. Aggregates the same enchanted-book
  pool as `loot_injections.json` by default (single source of truth) so any content edit to the
  loot side automatically flows to the structure-fill side.
- **New codec-registered utility:** `chiseled_enchanting_table:remove_enchanted_books` — a
  vanilla-style loot function data packs can reference to strip lore-less enchanted books from a
  specific vanilla loot table, without needing our Java to strip anything at boot.
- **`fabric.mod.json` port_notes** updated to reflect that mixins are now enabled, that the
  structure block-write side is intentionally gated, and that the legacy upstream anvil /
  enchanting-table / chiseled-bookshelf mixins are still parked.
- **`build.gradle` exclusions** refreshed: the port now compiles most of the upstream feature
  set; only integration / anvil / enchanting_table / accessor / chiseled_bookshelf mixins and the
  fully-superseded `modifyChestLootTable/` + `structureProcessor/` + `utils/ChiseledBookshelfLootTable`
  legacy sources are excluded.
- **Compat check (`scripts/compat_check.py`)** extended with two new Tier-1 well-formedness
  validators (`loot_injections.json` and `bookshelf_book_pool.json` schemas) + the two new JSON
  files are now part of the Tier-2 id-existence set.
- Validators run this round: `python3 scripts/compat_check.py` → PASS (1 warning — the auto-import
  copied `minecraft:chests/village_armorer` from upstream verbatim; the modern path is
  `minecraft:chests/village/village_armorer`. Documented but not auto-fixed to keep the derivation
  script's output faithful to the upstream Java).
- `./gradlew build --rerun-tasks` → BUILD SUCCESSFUL (17 s).
- Jar spot check: `chiseled_enchanting_table/mixin/structure/*.class` (4 mixins),
  `chiseled_enchanting_table/mechanics/loot/*.class`, `chiseled_enchanting_table/mechanics/structure/*.class`,
  `chiseled-enchanting-table-port.mixins.json`, and both new JSON tables all present. `mod_version`
  remains `1.0.0` (this is still the same in-development release).
- Release output refreshed under `release_output/chiseled_enchanting_table_1_0_0/`.

### Cover artwork refresh
- Replaced the in-jar mod icon `src/main/resources/assets/chiseled-enchanting-table/icon.png`
  (was 128×128) with the user-supplied 256×256 RGBA cover that already lived at the repo root as
  `icon.png` but had not been propagated into the packaged asset. Root `icon.png` and the asset
  copy now match (MD5 `13a8b073595249972ab65234fa2d45ba`) and the same bytes are embedded inside
  `chiseled-enchanting-table-1.0.0.jar` at `assets/chiseled-enchanting-table/icon.png`.
- Rebuilt the jar and refreshed `release_output/chiseled_enchanting_table_1_0_0/`:
  - `chiseled-enchanting-table-1.0.0.jar` (now 147 877 bytes, was 130 328 — icon swap).
  - `chiseled-enchanting-table-1.0.0-sources.jar`.
  - `chiseled-enchanting-table-1.0.0-source.zip` (working-tree zip).
  - **New: `cover-icon-256.png`** — 256×256 cover icon, ready to upload to Modrinth / CurseForge /
    MC百科 directly without re-extracting it from the jar.
  - **New: `cover-banner.png`** — repo root banner, staged alongside for the same reason.
- Validators: `python3 scripts/compat_check.py` -> PASS (2 warnings — MC jar / extra-jar not
  supplied; Tier 2 intentionally skipped). `./gradlew build --rerun-tasks` -> BUILD SUCCESSFUL.

### Distribution / listing copy
- Added `docs/marketing/` with ready-to-paste listing copy for the three distribution targets:
  - `docs/marketing/modrinth.md` — Modrinth project page (summary + full description).
  - `docs/marketing/curseforge.md` — CurseForge project page (summary + full description).
  - `docs/marketing/mcmod.md` — MC百科 (mcmod.cn) 中文简介、模组介绍正文、提交清单。
  - `docs/marketing/README.md` — index + universal "unofficial port" disclaimer (EN + ZH) to keep
    every listing consistent.
- Indexed the new folder in `docs/DOCUMENTATION_INDEX.md` under a new "Distribution / Listing
  Copy" section.
- No source/resource changes; no jar rebuild required for this round.


## [1.0.0] - 2026-07-01

First stable, publishable build of the unofficial 26.1.2 port. Renumbered from the internal
`0.2.3+26.1.2-p18` snapshot; no source/resource behaviour change beyond metadata rebranding.
Full details preserved in [`docs/CHANGELOG_HISTORY.md`](docs/CHANGELOG_HISTORY.md).

Headline: switched the unofficial port to a clean SemVer line, marked all user-facing surfaces
as an Unofficial 26.1.2 Port, rewrote `fabric.mod.json` metadata (name, description, authors,
contact, custom.port_notes), enabled the port's own mixin config
(`chiseled-enchanting-table-port.mixins.json`), and staged the first release artefacts under
`release_output/chiseled_enchanting_table_1_0_0/`.

## Older releases

See [`docs/CHANGELOG_HISTORY.md`](docs/CHANGELOG_HISTORY.md) — includes the P1-P19 internal
porting rounds (dated `2026-06-30 → 2026-07-01`) that built the port up before `1.0.0`, and the
full `[1.0.0]` entry.
