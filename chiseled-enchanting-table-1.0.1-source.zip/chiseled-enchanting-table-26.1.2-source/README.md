# Chiseled Enchanting Table — Unofficial 26.1.2 Port

![Chiseled enchanting table banner](./banner.png)

> ⚠️ **Unofficial community port.** This repository is a community-maintained, unofficial port of
> [Sacramentix/chiseled-enchanting-table](https://github.com/Sacramentix/chiseled-enchanting-table)
> updated to **Minecraft 26.1.2** on Fabric. It is **not affiliated with, endorsed by, or
> maintained by the original author**. All credit for the original mod design, code, and assets
> belongs to Sacramentix and is used under the original [MIT License](LICENSE). Please direct
> bug reports about this port to **this** repository (`q14433686-arch/chiseled-enchanting-table-26.1.2-source`),
> not to the upstream project.

**Current version:** `1.0.1` *(unofficial-port SemVer; see `CURRENT_BASELINE.md` for details)*
**Target:** Minecraft `26.1.2`, Fabric Loader `>=0.19.3`, Fabric API `0.151.0+26.1.2`, Java `>=25`.

A Minecraft Fabric mod that enhances the enchanting experience.

## Concept

* Add a new chiseled enchanting table
* Unlock new enchantment for chiseled enchanting table by placing enchanted book in nearby chiseled bookshelves
* Explore your world to discover new enchanted books!

## Installation

Grab the latest `chiseled-enchanting-table-1.0.1.jar` from
`release_output/chiseled_enchanting_table_1_0_1/` (or build it yourself with
`./gradlew build` using JDK 25 — see `NEXT_TASK.md` for the exact command chain) and drop it into
your Fabric `mods/` folder alongside Fabric API `0.151.0+26.1.2`.

This unofficial port is **not** currently published to Modrinth or CurseForge under the original
mod's listing. If a release is published, it will be under the unofficial-port repository's own
release page, not the upstream listing.

## Usage

Once installed, the Chiseled Enchanting Table will be available in your game. Craft it using the new recipe and start enchanting!

## Forge (or other modloader) port

Not planned at the moment.
But if the mod get more popular, I might have a look at it!

## Contributing

Contributions are welcome! Please feel free to submit a pull request or open an issue.

## License

This project is licensed under the [MIT License](LICENSE).

## Inspiration

I've looked at RPG enchanting table to get the base concept done
https://github.com/TheRedBrain/rpg-enchanting
If you are looking for a more RPG approch be sure to check out this mod!
